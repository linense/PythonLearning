source second_env/bin/activate

python sqlalchemy_script.py

deactivate
