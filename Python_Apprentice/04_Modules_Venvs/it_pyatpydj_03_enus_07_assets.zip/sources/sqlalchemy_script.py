import sqlalchemy

print("SQL Alchemy version: ", sqlalchemy.__version__)
