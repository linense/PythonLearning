print "Welcome to Pyhon 2!"
